package com.aplikasi.coba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CobaApplication.class, args);
	}

}
